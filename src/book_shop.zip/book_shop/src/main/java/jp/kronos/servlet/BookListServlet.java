package jp.kronos.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jp.kronos.DataSourceManager;

/**
 * Servlet implementation class BookListServlet
 */
@WebServlet("/list")
public class BookListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        
		try (Connection con = DataSourceManager.getConnection()) {
			// TODO Bookデータを全件検索する
			
			
			// TODO リクエストスコープにBookデータを保存する
			

			// TODO list.jspに転送する
			
		} catch (SQLException | NamingException e) {
			e.printStackTrace();
			throw new ServletException(e);
		}

	}

}
