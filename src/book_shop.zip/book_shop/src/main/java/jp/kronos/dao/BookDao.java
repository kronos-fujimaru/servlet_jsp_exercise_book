package jp.kronos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.kronos.dto.BookDto;

public class BookDao {
	private Connection con;

	public BookDao(Connection con) {
		this.con = con;
	}

	/**
	 * BOOKデータを全件検索する
	 * @return BOOKデータ
	 * @throws SQLException
	 */
	public List<BookDto> findAll() throws SQLException {
		String sql = "select ID, TITLE, PRICE from BOOK order by ID";
		
		try (PreparedStatement st = con.prepareStatement(sql)) {
			ResultSet rs = st.executeQuery();
			List<BookDto> bookList = new ArrayList<>();
			while (rs.next()) {
				BookDto book = new BookDto();
				book.setId(rs.getInt("ID"));
				book.setTitle(rs.getString("TITLE"));
				book.setPrice(rs.getInt("PRICE"));
				bookList.add(book);
			}
			return bookList;
		}
	}

	/**
	 * 引数のIDに紐づくBOOKデータを取得する
	 * @param id 取得対象ID
	 * @return BOOKデータ
	 * @throws SQLException
	 */
	public BookDto findByPrimaryKey(int id) throws SQLException {
		String sql = "select ID, TITLE, PRICE from BOOK where ID = ?";
		
		try (PreparedStatement st = con.prepareStatement(sql)) {
			st.setInt(1, id);
			ResultSet rs = st.executeQuery();
			BookDto book = new BookDto();
			if (rs.next()) {
				book.setId(rs.getInt("ID"));
				book.setTitle(rs.getString("TITLE"));
				book.setPrice(rs.getInt("PRICE"));
			}
			return book;
		}
	}

	/**
	 * BOOKデータを登録する
	 * @param book 登録データ
	 * @return 登録件数
	 * @throws SQLException
	 */
	public int create(BookDto book) throws SQLException {
		// FIXME カテゴリの追加
		String sql = "insert into BOOK (TITLE, PRICE) values (?, ?)";
		
		try (PreparedStatement st = con.prepareStatement(sql)) {
			st.setString(1, book.getTitle());
			st.setInt(2, book.getPrice());
			return st.executeUpdate();
		}
	}

	/**
	 * BOOKデータを更新する
	 * @param book 更新データ
	 * @return 更新件数
	 * @throws SQLException
	 */
	public int update(BookDto book) throws SQLException {
		String sql = "update BOOK set TITLE = ?, PRICE = ? where ID = ?";
		
		try (PreparedStatement st = con.prepareStatement(sql)) {
			st.setString(1, book.getTitle());
			st.setInt(2, book.getPrice());
			st.setInt(3, book.getId());
			return st.executeUpdate();
		}
	}

	/**
	 * BOOKデータを削除する
	 * @param id 削除対象ID
	 * @return 削除件数
	 * @throws SQLException
	 */
	public int delete(int id) throws SQLException {
		String sql = "delete from BOOK where ID = ?";
		
		try (PreparedStatement st = con.prepareStatement(sql)) {
			st.setInt(1, id);
			return st.executeUpdate();
		}
	}

}
