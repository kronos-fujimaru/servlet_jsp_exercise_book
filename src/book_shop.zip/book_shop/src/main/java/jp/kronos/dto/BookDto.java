package jp.kronos.dto;

public class BookDto {
	private Integer id;
	private String title;
	private Integer price;
	private Integer catId;

	public BookDto() {

	}

	public BookDto(String title, int price) {
		this.title = title;
		this.price = price;
	}

	public BookDto(String title, Integer price, Integer catId) {
		this(title, price);
		this.catId = catId;
	}

	public BookDto(int id, String title, int price) {
		this(title, price);
		this.id = id;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getCatId() {
		return catId;
	}

	public void setCatId(Integer catId) {
		this.catId = catId;
	}

}
