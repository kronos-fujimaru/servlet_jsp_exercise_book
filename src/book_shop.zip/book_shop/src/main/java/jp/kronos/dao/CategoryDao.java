package jp.kronos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jp.kronos.dto.CategoryDto;

public class CategoryDao {
	private Connection con;

	public CategoryDao(Connection con) {
		this.con = con;
	}
	
	/**
	 * CATEGORYデータを全件取得する
	 * @return CATEGORYデータ
	 * @throws SQLException
	 */
	public List<CategoryDto> findAll() throws SQLException {
		String sql = "select ID, CAT_NAME from CATEGORY order by ID";
		
		try (PreparedStatement st = con.prepareStatement(sql)) {
			ResultSet rs = st.executeQuery();
			List<CategoryDto> categoryList = new ArrayList<>();
			while (rs.next()) {
				CategoryDto category = new CategoryDto();
				category.setId(rs.getInt("ID"));
				category.setCatName(rs.getString("CAT_NAME"));
				categoryList.add(category);
			}
			return categoryList;
		}
	}
}
